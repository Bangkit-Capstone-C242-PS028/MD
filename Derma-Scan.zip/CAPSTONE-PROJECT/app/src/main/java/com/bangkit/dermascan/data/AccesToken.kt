package com.bangkit.dermascan.data


//class AccesToken {
//
//}
