package com.bangkit.dermascan.data.model.requestBody

//dataArticles class SkinLesionRequest ()