package com.bangkit.dermascan.ui.feeds

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.input.pointer.PointerIcon.Companion.Text

@Composable
fun FeedsScreen(){
    Text(text = "Feeds Screen")
}