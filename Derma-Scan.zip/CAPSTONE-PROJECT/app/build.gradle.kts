plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    id("com.google.gms.google-services")
    id ("kotlin-kapt")
    id ("dagger.hilt.android.plugin")
    id("kotlin-parcelize")

}

android {
    namespace = "com.bangkit.dermascan"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.bangkit.dermascan"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        buildConfigField("String","BASE_URL","\"https://dermascan-api-dev-991773542009.asia-southeast2.run.app/\"")
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables {
            useSupportLibrary = true
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    java {
        toolchain {
            languageVersion.set(JavaLanguageVersion.of(17)) // Set ke versi 22
        }
    }

    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
        buildConfig = true
        compose = true
    }

    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.1"
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }




}


dependencies {
    // Core dependencies
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)

    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    // Compose dependencies
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)

    // Hilt dependencies

    implementation(libs.firebase.auth.ktx)
    implementation(libs.androidx.navigation.runtime.ktx)
    implementation(libs.androidx.espresso.core)
    implementation(libs.androidx.runtime.livedata)
    implementation(libs.firebase.auth)
    implementation(libs.googleid)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.datastore.core.android)
    implementation(libs.material)
    implementation(libs.androidx.activity) //identity-google


    // Testing dependencies
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.ui.test.junit4)
    debugImplementation(libs.androidx.ui.tooling)
    debugImplementation(libs.androidx.ui.test.manifest)

    implementation("androidx.compose.material:material-icons-extended:1.4.3")
    // Lifecycle
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.7.0")
//    implementation("androidx.lifecycle:lifecycle-livedata-compose:2.7.0")
//    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
//    implementation("com.google.firebase:firebase-messaging-ktx:23.2.1")
//    implementation("com.google.auth:google-auth-library-oauth2-http:1.19.0")
    implementation(platform("com.google.firebase:firebase-bom:33.6.0"))
//    implementation ("com.google.firebase:firebase-auth-ktx:21.0.1")

//    implementation ("com.squareup.okhttp3:logging-interceptor:4.12.0")

    implementation("androidx.navigation:navigation-compose:2.5.3")

    implementation("androidx.datastore:datastore-preferences:1.0.0")
//    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.1")
//    implementation("androidx.lifecycle:lifecycle-livedata-ktx:2.6.1")
//    implementation("androidx.activity:activity-ktx:1.7.2")

    implementation ("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.6.4")
//    implementation ("androidx.lifecycle:lifecycle-viewmodel-ktx:2.6.1")
//    implementation ("androidx.lifecycle:lifecycle-runtime-ktx:2.6.1")

    implementation ("com.squareup.okhttp3:logging-interceptor:4.12.0")
    implementation ("com.squareup.retrofit2:converter-gson:2.11.0")
    implementation ("com.squareup.retrofit2:retrofit:2.9.0")
    implementation ("com.github.bumptech.glide:glide:4.16.0")
    annotationProcessor ("com.github.bumptech.glide:compiler:4.13.0")

    implementation ("androidx.cardview:cardview:1.0.0")

    implementation ("androidx.camera:camera-extensions:1.1.0")
    implementation ("androidx.camera:camera-camera2:1.1.0")
    implementation ("androidx.camera:camera-lifecycle:1.1.0")
    implementation ("androidx.camera:camera-view:1.1.0")
    implementation ("androidx.exifinterface:exifinterface:1.3.7")

    implementation ("com.google.android.gms:play-services-auth:21.1.1")
    implementation("androidx.credentials:credentials:1.2.2")

    //hilt
//    implementation(libs.hilt.android.v244)
//    kapt(libs.hilt.android.v244)
//    implementation("androidx.hilt:hilt-navigation-compose:1.0.0")
//    implementation(libs.hilt.android)
//    kapt(libs.hilt.compiler) // Gunakan kapt untuk Hilt compiler
    implementation ("com.google.dagger:hilt-android:2.48")
    kapt ("com.google.dagger:hilt-compiler:2.48")
    implementation ("androidx.hilt:hilt-navigation-compose:1.0.0")
    kapt("androidx.hilt:hilt-compiler:1.0.0")

    implementation("io.coil-kt.coil3:coil-compose:3.0.4")
//    implementation("io.coil-kt.coil3:coil-heif:3.0.4")
    implementation("io.coil-kt.coil3:coil-gif:3.0.4") // Untuk GIF
    implementation("io.coil-kt.coil3:coil-svg:3.0.4") // Untuk SVG
    //noinspection UseTomlInstead
    implementation("com.airbnb.android:lottie-compose:6.1.0")

    implementation ("com.github.bumptech.glide:glide:4.15.1")
//    implementation ("com.github.bumptech.glide:annotation:4.15.1")
    implementation ("io.noties.markwon:core:4.6.2")
//    implementation ("com.github.jeziellago:compose-markdown:0.3.0")
//    implementation ("com.github.jeziellago:compose-markdown:0.5.4")
    implementation ("com.facebook.shimmer:shimmer:0.5.0")
}

kapt {
    correctErrorTypes = true
    useBuildCache = true
    arguments {
        arg("dagger.hilt.android.internal.disableAndroidSuperclassValidation", "true")
    }
}

