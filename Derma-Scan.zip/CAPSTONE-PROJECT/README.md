git init <br/>
git add README.md  <br/>
git commit -m "first commit" <br/>
git branch -M main <br/>
git remote add origin https://github.com/Bangkit-Capstone-C242-PS028/MD.git <br/>
git push -u origin main <br/> <br/>

#existing <br/>
git remote add origin https://github.com/Bangkit-Capstone-C242-PS028/MD.git <br/>
git branch -M main <br/>
git push -u origin main <br/>
